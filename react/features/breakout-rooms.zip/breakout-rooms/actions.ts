import i18next from 'i18next';
import _ from 'lodash';

import { createBreakoutRoomsEvent } from '../analytics/AnalyticsEvents';
import { sendAnalytics } from '../analytics/functions';
import { IReduxState, IStore } from '../app/types';
import {
    conferenceLeft,
    conferenceWillLeave,
    createConference
} from '../base/conference/actions';
import { CONFERENCE_LEAVE_REASONS } from '../base/conference/constants';
import { getCurrentConference } from '../base/conference/functions';
import { fishMeetPassInData } from '../base/config/FishMeetPassInData';
import { setAudioMuted, setVideoMuted } from '../base/media/actions';
import { MEDIA_TYPE } from '../base/media/constants';
import { getLocalParticipant, getRemoteParticipants } from '../base/participants/functions';
import { createDesiredLocalTracks } from '../base/tracks/actions';
import {
    getLocalTracks,
    isLocalTrackMuted
} from '../base/tracks/functions';
import { clearNotifications, showNotification } from '../notifications/actions';
import { NOTIFICATION_TIMEOUT_TYPE } from '../notifications/constants';

import {
    IS_SHOW_LOADING, SET_ALL_ROOMS_OPEN,
    UPLOAD_PRE_BREAKROOMS, UPLOAD_RESULT,
    _RESET_BREAKOUT_ROOMS, _UPDATE_ROOM_COUNTER
} from './actionTypes';
import { FEATURE_KEY } from './constants';
import {
    getBreakoutRooms,
    getMainRoom,
    getRoomByJid
} from './functions';
import logger from './logger';
import { getAllRoomsData, getParticipantsByName } from './preRoomData';
import { IRoom } from './types';

/**
 * Action to create a breakout room.
 *
 * @param {string} name - Name / subject for the breakout room.
 * @returns {Function}
 */
export function createBreakoutRoom(name?: string) {
    return (dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        const state = getState();
        let { roomCounter } = state[FEATURE_KEY];
        const subject = name || i18next.t('breakoutRooms.defaultName', { index: ++roomCounter });

        sendAnalytics(createBreakoutRoomsEvent('create'));

        dispatch({
            type: _UPDATE_ROOM_COUNTER,
            roomCounter
        });

        getCurrentConference(state)?.getBreakoutRooms()
            ?.createBreakoutRoom(subject);
    };
}

/**
 * Action to close all rooms.
 *
 * @param {any} navigation - Navigation instance.
 * @returns {Function}
 */
export function closeAllRooms(navigation: any) {
    return async (dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        const state = getState();
        const rooms = getBreakoutRooms(state);

        dispatch(setIsShowLoading(true));

        Object.values(rooms).forEach(room => {
            if (!room.isMainRoom) {
                const participantIds = Object.keys(room.participants || {});

                if (participantIds.length > 0) {
                    dispatch(closeBreakoutRoom(room.id));
                }
            }
        });

        // Currently, the server cannot call this API at the same time.
        // You need to closeBreakoutRoom first and then removeBreakoutRoom.
        // Otherwise, there will be a bug when creating a meeting next time. We have delayed the wait here.
        await new Promise<void>(resolve => setTimeout(resolve, 5000));


        Object.values(rooms).forEach(room => {
            if (!room.isMainRoom) {
                dispatch(removeBreakoutRoom(room.jid));
            }
        });

        dispatch(setAllRoomsOpen(false));

        setTimeout(() => {
            dispatch(setIsShowLoading(false));
            navigation.goBack();
        }, 2000);
    };
}

/**
 * Action to open all rooms.
 *
 * @returns {Function}
 */
export function openAllRooms() {
    return (dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        const allRooms = getAllRoomsData();
        const state = getState();

        dispatch(setIsShowLoading(true));

        Object.values(allRooms).forEach(room => {
            if (!room.isMainRoom) {
                dispatch(createBreakoutRoom(room.name));
            }
        });

        setTimeout(() => {
            const startRooms = getBreakoutRooms(getState);
            const mainRoom = Object.values(startRooms).find(room => room.isMainRoom);

            Object.values(startRooms).forEach(room => {
                if (room.isMainRoom) {
                    return;
                }

                const participants = getParticipantsByName(room.name);

                if (participants) {
                    Object.values(participants).forEach(participant => {
                        if (mainRoom) {
                            const jid = getJidByEmail(participant.email, state, mainRoom);

                            if (jid) {
                                dispatch(sendParticipantToRoom(jid, room.id));
                            }
                        }
                    });
                }

            });

            dispatch(setAllRoomsOpen(true));
            dispatch(setIsShowLoading(false));
        }, 3000);
    };
}


/**
 * Action to getJidByEmail.
 *
 * @param {string | undefined} targetEmail - TargetEmail.
 * @param {IReduxState} state - State.
 * @param {IRoom} roomData - RoomData.
 * @returns {string | undefined}
 */
function getJidByEmail(targetEmail: string | undefined, state: IReduxState, roomData: IRoom) {
    const localParticipant = getLocalParticipant(state);
    const remoteParticipants = getRemoteParticipants(state);

    if (targetEmail === fishMeetPassInData.email) {
        const prefix = localParticipant?.id;
        const participantId = Object.keys(roomData.participants)
            .find(key => key.startsWith(`${roomData.jid}/${prefix}`));

        return participantId;
    }
    for (const participant of remoteParticipants.values()) {
        if (participant.email === targetEmail) {
            const prefix = participant.id;
            const participantId = Object.keys(roomData.participants)
                .find(key => key.startsWith(`${roomData.jid}/${prefix}`));

            return participantId;
        }
    }

    return undefined;
}


/**
 * Action to close a room and send participants to the main room.
 *
 * @param {string} roomId - The id of the room to close.
 * @returns {Function}
 */
export function closeBreakoutRoom(roomId: string) {
    return (dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        const rooms = getBreakoutRooms(getState);
        const room = rooms[roomId];
        const mainRoom = getMainRoom(getState);

        sendAnalytics(createBreakoutRoomsEvent('close'));

        if (room && mainRoom) {
            Object.values(room.participants).forEach(p => {
                dispatch(sendParticipantToRoom(p.jid, mainRoom.id));
            });
        }
    };
}

/**
 * Action to rename a breakout room.
 *
 * @param {string} breakoutRoomJid - The jid of the breakout room to rename.
 * @param {string} name - New name / subject for the breakout room.
 * @returns {Function}
 */
export function renameBreakoutRoom(breakoutRoomJid: string, name = '') {
    return (_dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        const trimmedName = name.trim();

        if (trimmedName.length !== 0) {
            sendAnalytics(createBreakoutRoomsEvent('rename'));
            getCurrentConference(getState)?.getBreakoutRooms()
                ?.renameBreakoutRoom(breakoutRoomJid, trimmedName);
        }
    };
}

/**
 * Action to remove a breakout room.
 *
 * @param {string} breakoutRoomJid - The jid of the breakout room to remove.
 * @returns {Function}
 */
export function removeBreakoutRoom(breakoutRoomJid: string) {
    return (dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        sendAnalytics(createBreakoutRoomsEvent('remove'));
        const room = getRoomByJid(getState, breakoutRoomJid);

        if (!room) {
            logger.error('The room to remove was not found.');

            return;
        }

        if (Object.keys(room.participants).length > 0) {
            dispatch(closeBreakoutRoom(room.id));
        }
        getCurrentConference(getState)?.getBreakoutRooms()
            ?.removeBreakoutRoom(breakoutRoomJid);
    };
}

/**
 * Action to auto-assign the participants to breakout rooms.
 *
 * @returns {Function}
 */
export function autoAssignToBreakoutRooms() {
    return (dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        const rooms = getBreakoutRooms(getState);
        const breakoutRooms = _.filter(rooms, room => !room.isMainRoom);

        if (breakoutRooms) {
            sendAnalytics(createBreakoutRoomsEvent('auto.assign'));
            const participantIds = Array.from(getRemoteParticipants(getState).keys());
            const length = Math.ceil(participantIds.length / breakoutRooms.length);

            _.chunk(_.shuffle(participantIds), length).forEach((group, index) =>
                group.forEach(participantId => {
                    dispatch(sendParticipantToRoom(participantId, breakoutRooms[index].id));
                })
            );
        }
    };
}

/**
 * Action to send a participant to a room.
 *
 * @param {string} participantId - The participant id.
 * @param {string} roomId - The room id.
 * @returns {Function}
 */
export function sendParticipantToRoom(participantId: string, roomId: string) {
    return (dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        const rooms = getBreakoutRooms(getState);
        const room = rooms[roomId];

        if (!room) {
            logger.warn(`Invalid room: ${roomId}`);

            return;
        }

        // Get the full JID of the participant. We could be getting the endpoint ID or
        // a participant JID. We want to find the connection JID.
        const participantJid = _findParticipantJid(getState, participantId);

        if (!participantJid) {
            logger.warn(`Could not find participant ${participantId}`);

            return;
        }

        getCurrentConference(getState)?.getBreakoutRooms()
            ?.sendParticipantToRoom(participantJid, room.jid);
    };
}

/**
 * Action to determineIfMoveParticipantToMainroom.
 *
 * @param {string} participantId - The participant id.
 * @param {string} roomId - The room id.
 * @returns {Function}
 */
export function determineIfMoveParticipantToMainroom(participantId: string, roomId: string) {
    return (dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        // The code here is executed after the meeting starts, if the participant is unselected in the panel.
        // If the current participant is in the current room, move the participant to the main room.
        // If not in the current room, do nothing.
        const findRoomId = _findRoomIdByParticipantJid(getState, participantId);
        const mainRoomId = getMainRoom(getState)?.id;

        if (findRoomId === roomId && mainRoomId) {
            dispatch(sendParticipantToRoom(participantId, mainRoomId));
        }
    };
}

/**
 * Action to _findRoomIdByParticipantJid.
 *
 * @param {IReduxState} getState - The state.
 * @param {string} participantId - The participant id.
 * @returns {string|undefined}
 */
function _findRoomIdByParticipantJid(getState: IStore['getState'], participantId: string): string | undefined {
    const rooms = getBreakoutRooms(getState);

    for (const [ roomId, room ] of Object.entries(rooms)) {
        const participants = room?.participants ?? {};

        for (const participant of Object.values(participants)) {
            if (participant?.jid === participantId) {
                return roomId;
            }
        }
    }

    return undefined;
}


/**
 * Action to move to a room.
 *
 * @param {string} roomId - The room id to move to. If omitted move to the main room.
 * @returns {Function}
 */
export function moveToRoom(roomId?: string) {
    return async (dispatch: IStore['dispatch'], getState: IStore['getState']) => {
        const mainRoomId = getMainRoom(getState)?.id;
        let _roomId: string | undefined | String = roomId || mainRoomId;

        // Check if we got a full JID.
        if (_roomId && _roomId?.indexOf('@') !== -1) {
            const [ id, ...domainParts ] = _roomId.split('@');

            // On mobile we first store the room and the connection is created
            // later, so let's attach the domain to the room String object as
            // a little hack.

            // eslint-disable-next-line no-new-wrappers
            _roomId = new String(id);

            // @ts-ignore
            _roomId.domain = domainParts.join('@');
        }

        const roomIdStr = _roomId?.toString();
        const goToMainRoom = roomIdStr === mainRoomId;
        const rooms = getBreakoutRooms(getState);
        const targetRoom = rooms[roomIdStr ?? ''];

        if (!targetRoom) {
            logger.warn(`Unknown room: ${targetRoom}`);

            return;
        }

        dispatch({
            type: _RESET_BREAKOUT_ROOMS
        });

        if (navigator.product === 'ReactNative') {
            const conference = getCurrentConference(getState);
            const { audio, video } = getState()['features/base/media'];

            dispatch(conferenceWillLeave(conference));

            try {
                await conference?.leave(CONFERENCE_LEAVE_REASONS.SWITCH_ROOM);
            } catch (error) {
                logger.warn('JitsiConference.leave() rejected with:', error);

                dispatch(conferenceLeft(conference));
            }

            dispatch(clearNotifications());
            dispatch(createConference(_roomId));
            dispatch(setAudioMuted(audio.muted));
            dispatch(setVideoMuted(Boolean(video.muted)));
            dispatch(createDesiredLocalTracks());
        } else {
            const localTracks = getLocalTracks(getState()['features/base/tracks']);
            const isAudioMuted = isLocalTrackMuted(localTracks, MEDIA_TYPE.AUDIO);
            const isVideoMuted = isLocalTrackMuted(localTracks, MEDIA_TYPE.VIDEO);

            try {
                // all places we fire notifyConferenceLeft we pass the room name from APP.conference
                await APP.conference.leaveRoom(false /* doDisconnect */, CONFERENCE_LEAVE_REASONS.SWITCH_ROOM).then(
                    () => APP.API.notifyConferenceLeft(APP.conference.roomName));
            } catch (error) {
                logger.warn('APP.conference.leaveRoom() rejected with:', error);

                // TODO: revisit why we don't dispatch CONFERENCE_LEFT here.
            }

            APP.conference.joinRoom(_roomId, {
                startWithAudioMuted: isAudioMuted,
                startWithVideoMuted: isVideoMuted
            });
        }

        if (goToMainRoom) {
            dispatch(showNotification({
                titleKey: 'breakoutRooms.notifications.joinedTitle',
                descriptionKey: 'breakoutRooms.notifications.joinedMainRoom',
                concatText: true,
                maxLines: 2
            }, NOTIFICATION_TIMEOUT_TYPE.MEDIUM));
        } else {
            dispatch(showNotification({
                titleKey: 'breakoutRooms.notifications.joinedTitle',
                descriptionKey: 'breakoutRooms.notifications.joined',
                descriptionArguments: { name: targetRoom.name },
                concatText: true,
                maxLines: 2
            }, NOTIFICATION_TIMEOUT_TYPE.MEDIUM));
        }
    };
}

/**
 * Finds a participant's connection JID given its ID.
 *
 * @param {Function} getState - The redux store state getter.
 * @param {string} participantId - ID of the given participant.
 * @returns {string|undefined} - The participant connection JID if found.
 */
function _findParticipantJid(getState: IStore['getState'], participantId: string) {
    const conference = getCurrentConference(getState);

    if (!conference) {
        return;
    }

    // Get the full JID of the participant. We could be getting the endpoint ID or
    // a participant JID. We want to find the connection JID.
    let _participantId = participantId;
    let participantJid;

    if (!participantId.includes('@')) {
        const p = conference.getParticipantById(participantId);

        _participantId = p?.getJid(); // This will be the room JID.
    }

    if (_participantId) {
        const rooms = getBreakoutRooms(getState);

        for (const room of Object.values(rooms)) {
            const participants = room.participants || {};
            const p = participants[_participantId]
                || Object.values(participants).find(item => item.jid === _participantId);

            if (p) {
                participantJid = p.jid;
                break;
            }
        }
    }

    return participantJid;
}

/**
 * Action to Set all rooms to open.
 *
 * @param {boolean} areAllRoomsOpen - AreAllRoomsOpen.
 * @returns {Function}
 */
export function setAllRoomsOpen(areAllRoomsOpen: boolean) {
    return (dispatch: IStore['dispatch']) => {
        dispatch({
            type: SET_ALL_ROOMS_OPEN,
            areAllRoomsOpen
        });
    };
}

/**
 * Action to setIsShowLoading.
 *
 * @param {boolean} isShowLoading - IsShowLoading.
 * @returns {Function}
 */
export function setIsShowLoading(isShowLoading: boolean) {
    return (dispatch: IStore['dispatch']) => {
        dispatch({
            type: IS_SHOW_LOADING,
            isShowLoading
        });
    };
}

/**
 * Action to Upload preloaded room data.
 *
 * @param {any} meetingData - MeetingData.
 * @returns {Function}
 */
export function upLoadPreBreakRoomsData(meetingData: any) {
    return (dispatch: IStore['dispatch']) => {
        fishMeetPassInData.breakRoomData = meetingData;
        dispatch({
            type: UPLOAD_PRE_BREAKROOMS,
            meetingData
        });
    };
}

/**
 * Action to Set the result of the upload, success or failure.
 *
 * @param {boolean | undefined} uploadResult - UploadResult.
 * @returns {Function}
 */
export function setUploadResult(uploadResult: boolean | undefined) {
    return (dispatch: IStore['dispatch']) => {
        dispatch({
            type: UPLOAD_RESULT,
            uploadResult
        });
    };
}





