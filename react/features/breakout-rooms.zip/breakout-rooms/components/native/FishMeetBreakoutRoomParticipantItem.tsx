import React, { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { IReduxState } from '../../../app/types';
import { isLocalParticipantModerator } from '../../../base/participants/functions';
import { showRoomParticipantMenu } from '../../../participants-pane/actions.native';
import FishMeetAvatarGridItem from '../../../participants-pane/components/native/FishMeetAvatarGridItem';
import { IRoom } from '../../types';

interface IProps {

    /**
     * Participant to be displayed.
     */
    item: any;

    /**
     * The room the participant is in.
     */
    room: IRoom;
}

const FishMeetBreakoutRoomParticipantItem = ({ item, room }: IProps) => {
    const { defaultRemoteDisplayName = '' } = useSelector((state: IReduxState) => state['features/base/config']);
    const moderator = useSelector(isLocalParticipantModerator);
    const dispatch = useDispatch();
    const onPress = useCallback(() => {
        if (moderator) {
            dispatch(showRoomParticipantMenu(room, item.jid, item.displayName));
        }
    }, [ moderator, room, item ]);

    return (
        <FishMeetAvatarGridItem
            displayName = { (item.displayName || defaultRemoteDisplayName) }
            isNotInMeeting = { item.isNotInMeeting }
            key = { item.jid }
            onPress = { onPress }
            participantID = { item.jid } />
    );
};

export default FishMeetBreakoutRoomParticipantItem;
