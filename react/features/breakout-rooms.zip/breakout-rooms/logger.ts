import { getLogger } from '../base/logging/functions';

import { FEATURE_KEY } from './constants';

export default getLogger(FEATURE_KEY);
